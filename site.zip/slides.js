// Презентации листаются как в PowerPoint: одно нажатие — следующий слайд сразу анимируется и замирает.
// Для каждого слайда: [когда он уже собран, когда начинается переход к следующему] — секунды в видео.
const SLIDES = {simurg:[[7.4,8.6],[11.9,14.7],[16.8,20.5],[23.35,28.65],[33,35.95],[37.6,40.6],[43.8,50],[55.6,56.75],[58.8,62.7],[66.95,68.4],[72.8,74.1],[78.25,79.6],[82.6,86.55],[91,92.2]]};
(() => {
 const stage=document.querySelector('.slides-stage');if(!stage)return;
 const v=stage.querySelector('video'),deck=SLIDES[stage.dataset.deck],n=deck.length;
 const pos=stage.querySelector('.slides-pos'),pad=k=>String(k).padStart(2,'0');
 let cur=-1,target=null,raf=0;
 const label=()=>{pos.textContent=pad(Math.max(cur,0)+1)+' / '+pad(n);stage.querySelector('.slides-prev').disabled=cur<=0;stage.querySelector('.slides-next').disabled=cur>=n-1;};
 // следим за временем каждый кадр, чтобы замереть ровно на собранном слайде
 const watch=()=>{if(target===null)return;if(v.currentTime>=target-.04||v.ended){v.pause();target=null;return;}raf=requestAnimationFrame(watch);};
 const go=i=>{
  cancelAnimationFrame(raf);
  // следующий слайд: начинаем с перехода от текущего, даже если тот ещё анимировался
  const from=i===0?0:deck[i-1][1];
  cur=i;target=deck[i][0];label();
  if(Math.abs(v.currentTime-from)>.05)v.currentTime=from;
  v.play().catch(()=>{});raf=requestAnimationFrame(watch);
 };
 const show=i=>{cancelAnimationFrame(raf);target=null;v.pause();cur=i;v.currentTime=deck[i][0];label();};
 const next=()=>{if(cur<n-1)go(cur+1);};
 const prev=()=>{if(cur>0)show(cur-1);else go(0);};
 const start=()=>{stage.classList.add('started');go(0);stage.focus({preventScroll:true});};
 stage.querySelector('.slides-play').addEventListener('click',start);
 stage.querySelector('.slides-next').addEventListener('click',e=>{e.stopPropagation();next();});
 stage.querySelector('.slides-prev').addEventListener('click',e=>{e.stopPropagation();prev();});
 stage.querySelector('.slides-full').addEventListener('click',e=>{e.stopPropagation();document.fullscreenElement?document.exitFullscreen():(stage.requestFullscreen||stage.webkitRequestFullscreen)?.call(stage);});
 v.addEventListener('click',()=>{if(stage.classList.contains('started'))next();});
 let inView=false;
 document.addEventListener('keydown',e=>{
  if(!stage.classList.contains('started')||!(inView||document.fullscreenElement===stage)||e.target.closest?.('input,textarea'))return;
  if(['ArrowRight','PageDown',' '].includes(e.key)){e.preventDefault();next();}
  else if(['ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();prev();}
 });
 let sx=null;v.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')sx=e.clientX;});
 v.addEventListener('pointerup',e=>{if(sx===null)return;const dx=e.clientX-sx;sx=null;if(Math.abs(dx)>50){e.preventDefault();dx<0?next():prev();}});
 // видео начинаем грузить заранее, когда раздел подъезжает к экрану, — чтобы с первого нажатия всё играло
 new IntersectionObserver(([e],o)=>{if(e.isIntersecting){v.preload='auto';v.load();o.disconnect();}},{rootMargin:'800px 0px'}).observe(stage);
 new IntersectionObserver(([e])=>{inView=e.intersectionRatio>.5;if(!e.isIntersecting&&target!==null)show(cur);},{threshold:[0,.5]}).observe(stage);
 // если видео подгружается — показываем индикатор поверх слайда
 v.addEventListener('waiting',()=>stage.classList.add('buffering'));
 ['playing','seeked','canplay','pause'].forEach(t=>v.addEventListener(t,()=>stage.classList.remove('buffering')));
 label();
})();
