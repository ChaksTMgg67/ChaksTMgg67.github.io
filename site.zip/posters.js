// Галереи небольших работ: афиши, визитки и всё, что добавится дальше.
// Чтобы добавить работу — допиши объект в нужный список. Карточки, счётчики и просмотр строятся сами.
const GALLERIES={
 posters:{label:'АФИШИ / ПОСТЕРЫ',kind:'постер',items:[
  {title:'Музыкальное лото',category:'События',thumb:'assets/posters/lotto-thumb.webp',w:960,h:640,views:['assets/posters/lotto-0.webp']},
  {title:'Наши люди',category:'События',thumb:'assets/posters/people-thumb.webp',w:960,h:640,views:['assets/posters/people-0.webp']},
  {title:'Раскрой свой голос',category:'Бренды',thumb:'assets/posters/voks-thumb.webp',w:960,h:640,views:['assets/posters/voks-0.webp']},
  {title:'Залетай в Swallow',category:'Бренды',thumb:'assets/posters/swallow-thumb.webp',w:960,h:720,views:['assets/posters/swallow-0.webp']},
  {title:'Мастер-классы',category:'События',thumb:'assets/posters/dance-thumb.webp',w:960,h:541,views:['assets/posters/dance-0.webp','assets/posters/dance-1.webp']},
  {title:'Овер Повер',category:'Бренды',thumb:'assets/posters/vr-thumb.webp',w:960,h:640,views:['assets/posters/vr-0.webp']},
  {title:'Бурый мишка',category:'Бренды',thumb:'assets/posters/bear-thumb.webp',w:960,h:540,views:['assets/posters/bear-0.webp','assets/posters/bear-1.webp']},
  {title:'Сделай добро',category:'Бренды',thumb:'assets/posters/kind-thumb.webp',w:960,h:670,views:['assets/posters/kind-0.webp']},
  {title:'Скоро лето',category:'Эксперименты',thumb:'assets/posters/summer-thumb.webp',w:960,h:640,views:['assets/posters/summer-0.webp']}
 ]},
 cards:{label:'ВИЗИТКИ',kind:'визитка',items:[
  {title:'Lappie',category:'Бренд',thumb:'assets/cards/c1-thumb.webp',w:960,h:640,views:['assets/cards/c1.webp']},
  {title:'Арт Хаус',category:'Студия',thumb:'assets/cards/c2-thumb.webp',w:960,h:640,views:['assets/cards/c2.webp']},
  {title:'Вокс',category:'Школа вокала',thumb:'assets/cards/c3-thumb.webp',w:960,h:640,views:['assets/cards/c3.webp']},
  {title:'Level',category:'Личный бренд',thumb:'assets/cards/c4-thumb.webp',w:960,h:640,views:['assets/cards/c4.webp']},
  {title:'Свадебный салон',category:'Салон',thumb:'assets/cards/c5-thumb.webp',w:960,h:640,views:['assets/cards/c5.webp']},
  {title:'Я на тату',category:'Тату-студия',thumb:'assets/cards/c6-thumb.webp',w:960,h:640,views:['assets/cards/c6.webp']},
  {title:'Ноздрин',category:'Врач',thumb:'assets/cards/c7-thumb.webp',w:960,h:640,views:['assets/cards/c7.webp']}
 ]}
};
(() => {
 const pad=n=>String(n).padStart(2,'0');
 const dialog=document.querySelector('#poster-dialog'),image=document.querySelector('#poster-full'),detail=document.querySelector('#poster-detail');
 let gallery=null,selected=0,variant=0,returnTo=null,previousOverflow='';
 const state={};

 document.querySelectorAll('[data-gallery]').forEach(section=>{
  const key=section.dataset.gallery,g=GALLERIES[key];if(!g)return;
  const grid=section.querySelector('.poster-grid'),count=section.querySelector('.gallery-count'),filters=[...section.querySelectorAll('[data-filter]')];
  grid.innerHTML=g.items.map((p,i)=>`<button class="poster-card" data-index="${i}" data-category="${p.category}" aria-label="Открыть: ${p.title}"><span class="poster-image"><img src="${p.thumb}" alt="${p.title} — ${g.kind} на носителе" width="${p.w}" height="${p.h}" loading="lazy" decoding="async"><span class="poster-plus" aria-hidden="true">↗</span></span><span class="poster-caption"><span><small>${p.category}</small><strong>${p.title}</strong></span><span class="poster-number">${pad(i+1)}</span></span></button>`).join('');
  const cards=[...grid.children];
  state[key]={visible:g.items.map((_,i)=>i)};
  const setCount=()=>{if(count)count.textContent=pad(state[key].visible.length)+(state[key].visible.length===g.items.length?' работ':' / '+pad(g.items.length));};
  setCount();
  cards.forEach(c=>c.addEventListener('click',()=>open(key,Number(c.dataset.index),c)));
  filters.forEach(b=>b.addEventListener('click',()=>{
   filters.forEach(f=>f.setAttribute('aria-pressed',String(f===b)));
   state[key].visible=[];
   cards.forEach(c=>{c.hidden=b.dataset.filter!=='Все'&&c.dataset.category!==b.dataset.filter;if(!c.hidden)state[key].visible.push(Number(c.dataset.index));});
   setCount();
  }));
 });

 // Счётчики в переключателе разделов берутся из данных, чтобы не расходились.
 document.querySelectorAll('.work-switch a').forEach(a=>{const g=GALLERIES[a.hash.slice(1)];if(g)a.querySelector('span').textContent=pad(g.items.length);});

 function render(){
  const g=GALLERIES[gallery],p=g.items[selected],vis=state[gallery].visible;
  image.src=p.views[variant];image.alt=p.title+' — '+(variant?'крупный план':g.kind+' на носителе');
  document.querySelector('#poster-title').textContent=p.title;
  document.querySelector('#poster-category').textContent=p.category;
  document.querySelector('#poster-label').textContent=g.label;
  document.querySelector('#poster-position').textContent=pad(vis.indexOf(selected)+1)+' / '+pad(vis.length);
  detail.hidden=p.views.length<2;detail.setAttribute('aria-pressed',String(!!variant));detail.textContent=variant?'Общий вид ↙':'Крупный план ↗';
  document.querySelectorAll('.poster-prev,.poster-next').forEach(b=>b.hidden=vis.length<2);
 }
 function open(key,i,trigger){gallery=key;selected=i;variant=0;returnTo=trigger;previousOverflow=document.body.style.overflow;render();dialog.showModal();document.body.style.overflow='hidden';document.querySelector('#poster-close').focus();}
 function step(delta){const vis=state[gallery].visible;selected=vis[(vis.indexOf(selected)+delta+vis.length)%vis.length];variant=0;render();}
 document.querySelector('#poster-close').addEventListener('click',()=>dialog.close());
 dialog.addEventListener('close',()=>{document.body.style.overflow=previousOverflow;image.removeAttribute('src');returnTo?.focus({preventScroll:true});});
 document.querySelector('.poster-prev').addEventListener('click',()=>step(-1));document.querySelector('.poster-next').addEventListener('click',()=>step(1));
 detail.addEventListener('click',()=>{variant=1-variant;render();});
 dialog.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();step(e.key==='ArrowRight'?1:-1);}});
 let start=null;const stage=document.querySelector('.poster-stage');stage.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')start={x:e.clientX,y:e.clientY};});stage.addEventListener('pointerup',e=>{if(start){const dx=e.clientX-start.x,dy=e.clientY-start.y;if(Math.abs(dx)>55&&Math.abs(dx)>Math.abs(dy)*1.5)step(dx<0?1:-1);start=null;}});stage.addEventListener('pointercancel',()=>start=null);
})();
