// Оформление ВКонтакте: один шаблон, переключаются проекты.
// Чтобы добавить проект — допиши объект: desk (страница целиком) или cover+avatar (соберём страницу сами),
// phone — мобильная обложка в телефоне, live — живая (анимированная) обложка, играет прямо в экране телефона, buttons — кнопки меню, stories — обложки «Актуального».
const VK = [
 {name:'Блин Rocky',cat:'Блинная',cover:'assets/vk/blin-cover.webp',avatar:'assets/vk/blin-avatar.webp',phone:'assets/vk/blin-phone.webp',live:'assets/vk/blin-live.mp4',livePoster:'assets/vk/blin-live-poster.webp',
  buttons:[['assets/vk/blin-b1.webp','Наше меню'],['assets/vk/blin-b2.webp','Как нас найти'],['assets/vk/blin-b3.webp','Ваши отзывы']],
  stories:[['assets/vk/blin-s1.webp','блины'],['assets/vk/blin-s2.webp','доставка'],['assets/vk/blin-s3.webp','наш дом'],['assets/vk/blin-s4.webp','акции'],['assets/vk/blin-s5.webp','отзывы']]},
 {name:'Вокс',cat:'Студия вокала',desk:'assets/vk/voks-desk.webp',phone:'assets/vk/voks-phone.webp'},
 {name:'Арт Хаус',cat:'Студия танцев',desk:'assets/vk/art-desk.webp',phone:'assets/vk/art-phone.webp',
  buttons:[['assets/vk/art-b1.webp','Запись'],['assets/vk/art-b2.webp','О нас'],['assets/vk/art-b3.webp','Отзывы']]},
 {name:'Про движение',cat:'Личный бренд',desk:'assets/vk/promo-desk.webp',phone:'assets/vk/promo-phone.webp'},
 {name:'Лимпопо',cat:'Детская одежда',desk:'assets/vk/limpopo-desk.webp'},
 {name:'Tender W Company',cat:'Тендерная компания',desk:'assets/vk/tender-desk.webp'}
];
(() => {
 const sec=document.querySelector('#vk');if(!sec)return;
 const pad=n=>String(n).padStart(2,'0');
 const tabs=sec.querySelector('.vk-tabs'),stage=sec.querySelector('.vk-stage'),desk=sec.querySelector('.vk-desk'),phone=sec.querySelector('.vk-phone'),
  dImg=desk.querySelector('img'),pImg=phone.querySelector('img'),extra=sec.querySelector('.vk-extra');
 tabs.innerHTML=VK.map((p,i)=>`<button role="tab" aria-selected="${i===0}" data-i="${i}">${p.name}</button>`).join('');
 const btns=[...tabs.children];
 let cur=-1,visible=false;
 const load=src=>new Promise(r=>{if(!src)return r();const im=new Image();im.onload=im.onerror=()=>r();im.src=src;});
 const preload=i=>{const p=VK[i];[p.desk,p.cover,p.phone].forEach(s=>s&&load(s));};
 function fill(p){
  // десктоп: готовая страница или собираем из шапки и аватара
  desk.classList.toggle('compose',!p.desk);
  desk.querySelector('.vk-bar')?.remove();
  dImg.src=p.desk||p.cover;dImg.alt=`${p.name} — оформление сообщества ВКонтакте`;
  if(!p.desk){desk.insertAdjacentHTML('beforeend',`<div class="vk-bar"><img src="${p.avatar}" alt=""><span></span><span></span><b></b></div>`);}
  phone.hidden=!p.phone;stage.classList.toggle('no-phone',!p.phone);
  if(p.phone){pImg.src=p.phone;pImg.alt=`${p.name} — мобильная обложка`;}
  // живая обложка: видео поверх экрана телефона, играет только пока раздел на экране
  phone.querySelector('video')?.remove();phone.classList.toggle('has-live',!!p.live);
  if(p.live){phone.insertAdjacentHTML('beforeend',`<video class="vk-live" muted loop playsinline preload="none" poster="${p.livePoster||''}" aria-label="${p.name} — живая обложка"><source src="${p.live}" type="video/mp4"></video>`);if(visible)phone.querySelector('video').play().catch(()=>{});}
  sec.querySelector('.vk-cat').textContent=p.cat;
  sec.querySelector('.vk-name').textContent=p.name;
  sec.querySelector('.vk-pos').textContent=pad(VK.indexOf(p)+1)+' / '+pad(VK.length);
  const parts=['шапка','аватар'];if(p.phone)parts.push(p.live?'живая обложка':'мобильная обложка');if(p.buttons)parts.push('кнопки меню');if(p.stories)parts.push('актуальное');
  sec.querySelector('.vk-parts').innerHTML=parts.map(t=>`<span>${t}</span>`).join('');
  extra.innerHTML=(p.buttons?`<div class="vk-block"><small>Меню</small><div class="vk-buttons">${p.buttons.map(([s,t])=>`<figure><img src="${s}" alt="${t}" loading="lazy"><figcaption>${t}</figcaption></figure>`).join('')}</div></div>`:'')+
   (p.stories?`<div class="vk-block"><small>Актуальное</small><div class="vk-stories">${p.stories.map(([s,t])=>`<figure><img src="${s}" alt="${t}" loading="lazy"><figcaption>${t}</figcaption></figure>`).join('')}</div></div>`:'');
  extra.hidden=!extra.innerHTML;
 }
 async function show(i,first){
  i=(i+VK.length)%VK.length;if(i===cur)return;cur=i;
  btns.forEach((b,k)=>b.setAttribute('aria-selected',String(k===i)));
  // крутим только ленту вкладок по горизонтали — страницу не трогаем
  const b=btns[i];tabs.scrollTo({left:b.offsetLeft-(tabs.clientWidth-b.offsetWidth)/2,behavior:first?'auto':'smooth'});
  const p=VK[i];
  if(first){fill(p);preload((i+1)%VK.length);return;}
  stage.classList.add('out');extra.classList.add('out');
  await Promise.all([load(p.desk||p.cover),load(p.phone),new Promise(r=>setTimeout(r,280))]);
  if(cur!==i)return;
  fill(p);
  requestAnimationFrame(()=>{stage.classList.remove('out');extra.classList.remove('out');});
  preload((i+1)%VK.length);
 }
 btns.forEach(b=>b.addEventListener('click',()=>show(Number(b.dataset.i))));
 tabs.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();show(cur+(e.key==='ArrowRight'?1:-1));btns[cur].focus();}});
 sec.querySelector('.vk-prev').addEventListener('click',()=>show(cur-1));
 sec.querySelector('.vk-next').addEventListener('click',()=>show(cur+1));
 let sx=null;stage.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')sx={x:e.clientX,y:e.clientY};});
 stage.addEventListener('pointerup',e=>{if(!sx)return;const dx=e.clientX-sx.x,dy=e.clientY-sx.y;sx=null;if(Math.abs(dx)>50&&Math.abs(dx)>Math.abs(dy)*1.4)show(cur+(dx<0?1:-1));});
 stage.addEventListener('pointercancel',()=>sx=null);
 // раздел заполняем сразу, чтобы его высота не менялась во время прокрутки; картинки грузятся лениво
 show(0,true);
 new IntersectionObserver(([e])=>{visible=e.isIntersecting;const vd=phone.querySelector('video');if(vd){visible?vd.play().catch(()=>{}):vd.pause();}},{threshold:.2}).observe(stage);
})();
