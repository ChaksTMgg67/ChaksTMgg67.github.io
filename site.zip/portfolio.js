(() => {
  const projects = window.PORTFOLIO;
  const baseTitle = document.title;
  const dialog = document.getElementById('project-dialog');
  const content = document.getElementById('project-body');
  const title = document.querySelector('.case-toolbar-name');
  const bar = document.querySelector('.case-reading');
  let savedY = 0, returnFocus = null, current = null, mediaObserver = null;
  let ownedHistory = false;
  const esc = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const typo = text => text.replace(/(^|\s)(в|и|с|к|о|у|а|на|по|за|из|от|до|не|для|как) /gi, '$1$2\u00a0').replace(/ — /g,'\u00a0— ');
  const getId = () => location.hash.startsWith('#project/') ? decodeURIComponent(location.hash.slice(9)) : null;
  function renderMedia(m, index, project) {
    if (m.type === 'image') return `<figure><img src="${esc(m.src)}" alt="${esc(m.alt)}" loading="${index<2?'eager':'lazy'}" decoding="async" ${m.width?`width="${m.width}" height="${m.height}"`:''}></figure>`;
    const label = `${project.title} · моушн ${project.media.slice(0,index+1).filter(x=>x.type!=='image').length}`;
    if(m.type==='video') return `<figure class="case-video"><video controls playsinline preload="metadata" ${m.poster?`poster="${esc(m.poster)}"`:''}><source src="${esc(m.src)}" type="${esc(m.mime||'video/mp4')}">Ваш браузер не поддерживает видео. <a href="${esc(m.src)}">Открыть файл</a></video></figure>`;
    return `<figure class="case-video"><div class="case-video-frame" style="aspect-ratio:${Number(m.aspectRatio)||16/9}"><iframe data-src="${esc(m.src)}" title="${esc(label)}" allow="autoplay; fullscreen; picture-in-picture; encrypted-media" allowfullscreen loading="lazy"></iframe></div></figure>`;
  }
  function openProject(id) {
    const p = projects.find(p=>p.id===id);
    if (!p) { if(dialog.open) closeProject(); return; }
    if (!dialog.open) {
      savedY = window.scrollY; returnFocus = document.activeElement;
      document.body.style.overflow = 'hidden';
      document.body.classList.add('reading-project');
      dialog.showModal();
    }
    mediaObserver?.disconnect(); current = p;
    const next = projects[(projects.indexOf(p)+1)%projects.length];
    document.title = `${p.title} — Иван Долганов`;
    title.textContent = p.title;
    content.innerHTML = `<header class="case-intro"><div class="case-topline"><span>[ ${String(projects.indexOf(p)+1).padStart(2,'0')} / проект ]</span><span>${esc(p.year)} · Иван Долганов</span></div><h2 id="project-title" tabindex="-1">${esc(p.title)}<br><span>${esc(p.subtitle)}</span></h2><div class="case-summary"><p>${esc(typo(p.description))}</p><div class="tags">${p.tags.split(' · ').map(t=>`<span class="chip">${esc(t)}</span>`).join('')}</div></div></header><div class="case-feed">${p.media.map((m,i)=>renderMedia(m,i,p)).join('')}</div><footer class="case-end"><div class="case-end-links"><a class="ext" href="${esc(p.url)}" target="_blank" rel="noopener">Оригинал на Behance ↗</a><a class="btn" href="https://t.me/Ivs354" target="_blank" rel="noopener">Обсудить проект ↗</a></div><a class="case-next" href="#project/${next.id}"><div><small>Следующий проект</small><strong>${esc(next.title)}</strong></div><span>↗</span></a></footer>`;
    dialog.scrollTop=0;bar.style.transform='scaleX(0)';
    document.getElementById('project-title').focus({preventScroll:true});
    mediaObserver=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){if(!e.target.hasAttribute('src'))e.target.src=e.target.dataset.src;}else if(e.target.hasAttribute('src')){e.target.removeAttribute('src');}}),{root:dialog,rootMargin:'600px'});
    content.querySelectorAll('iframe[data-src]').forEach(f=>mediaObserver.observe(f));
    content.querySelectorAll('img').forEach(img=>img.addEventListener('error',()=>{img.hidden=true;const note=document.createElement('p');note.className='image-fallback';note.textContent='Изображение не загрузилось. Полная версия доступна по ссылке на Behance в конце проекта.';img.after(note)},{once:true}));
  }
  function closeProject(){
    mediaObserver?.disconnect();content.querySelectorAll('video').forEach(v=>v.pause());content.innerHTML='';
    dialog.close();current=null;document.body.style.overflow='';
    document.title=baseTitle;
    window.scrollTo({top:savedY,behavior:'instant'});returnFocus?.focus({preventScroll:true});
    document.body.classList.remove('reading-project');
  }
  function requestClose(){if(ownedHistory){history.back();}else{history.replaceState(null,'',location.pathname+location.search+'#work');closeProject();}ownedHistory=false;}
  document.addEventListener('click',event=>{
    const link=event.target.closest('a[href^="#project/"]');if(!link)return;
    event.preventDefault();const id=link.getAttribute('href').slice(9);
    if(dialog.open) history.replaceState({project:id},'',`#project/${id}`);
    else {history.pushState({project:id},'',`#project/${id}`);ownedHistory=true;}
    openProject(id);
  });
  document.querySelector('.case-close').addEventListener('click',requestClose);
  document.querySelector('.case-back').addEventListener('click',e=>{e.preventDefault();requestClose()});
  dialog.addEventListener('cancel',e=>{e.preventDefault();requestClose()});
  dialog.addEventListener('scroll',()=>{const max=dialog.scrollHeight-dialog.clientHeight;bar.style.transform=`scaleX(${max?dialog.scrollTop/max:0})`},{passive:true});
  window.addEventListener('popstate',()=>{const id=getId();if(id)openProject(id);else if(dialog.open)closeProject()});
  if(getId())openProject(getId());
  document.querySelectorAll('.hero__lead,.about p,.stats .chip').forEach(el=>{
    const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let n;while(n=walker.nextNode())n.textContent=typo(n.textContent);
  });
})();
