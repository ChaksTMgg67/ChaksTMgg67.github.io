window.PORTFOLIO = [
  {
    "id": "swallow",
    "title": "Swallow",
    "subtitle": "Fresh Drinks",
    "tags": "айдентика · упаковка · моушн",
    "year": "2026",
    "cover": "assets/work/swallow-cup.webp",
    "description": "Кофейня, в которой ласточка — не просто логотип, а характер бренда: лёгкость, движение и свобода. Знак, упаковка, полиграфия и моушн в одной системе.",
    "url": "https://www.behance.net/gallery/244574463/Swallow-Fresh-Drinks-Brand-Identity-Packaging",
    "media": [
      {
        "type": "image",
        "src": "assets/cases/swallow/00.webp",
        "alt": "Swallow — разворот 1",
        "width": 1400,
        "height": 1080
      },
      {
        "type": "image",
        "src": "assets/cases/swallow/01.webp",
        "alt": "Swallow — разворот 2",
        "width": 1400,
        "height": 797
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/gD2YF9Xa4Wi59LTVaf84KS",
        "aspectRatio": 1.7481481481481482
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/8BCpjbstXiats6UmsSCaik",
        "aspectRatio": 1.6222222222222222
      },
      {
        "type": "image",
        "src": "assets/cases/swallow/04.webp",
        "alt": "Swallow — разворот 5",
        "width": 1400,
        "height": 933
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/ah7J1drNuzdsrb3zXPn4qY",
        "aspectRatio": 1.7482517482517481
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/3dvhnDiK1YUGcyBs6cp7By",
        "aspectRatio": 1.7485574401119077
      },
      {
        "type": "image",
        "src": "assets/cases/swallow/07.webp",
        "alt": "Swallow — разворот 8",
        "width": 1400,
        "height": 950
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/xjp1RxiY5h4DndgY8k6ivw",
        "aspectRatio": 1.554243083618278
      },
      {
        "type": "image",
        "src": "assets/cases/swallow/09.webp",
        "alt": "Swallow — разворот 10",
        "width": 1400,
        "height": 900
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/8NW24qr6M3M5xEEne8J1g4",
        "aspectRatio": 1.554243083618278
      },
      {
        "type": "image",
        "src": "assets/cases/swallow/11.webp",
        "alt": "Swallow — разворот 12",
        "width": 1400,
        "height": 822
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/prhQLkiP7RxMaQXeMSFVvL",
        "aspectRatio": 1.7485574401119077
      },
      {
        "type": "image",
        "src": "assets/cases/swallow/13.webp",
        "alt": "Swallow — разворот 14",
        "width": 1400,
        "height": 822
      },
      {
        "type": "image",
        "src": "assets/cases/swallow/14.webp",
        "alt": "Swallow — разворот 15",
        "width": 1400,
        "height": 750
      }
    ]
  },
  {
    "id": "voks",
    "title": "Вокс",
    "subtitle": "Школа вокала",
    "tags": "айдентика · мерч · веб",
    "year": "2026",
    "cover": "assets/work/voks-logo.webp",
    "description": "Визуальная форма голоса. Айдентика студии вокала Екатерины Костиной: глубокий чёрный, активный оранжевый и графика звуковой волны.",
    "url": "https://www.behance.net/gallery/246293201/voks-ajdentika-shkoly-vokala",
    "media": [
      {
        "type": "image",
        "src": "assets/cases/voks/00.webp",
        "alt": "Вокс — разворот 1",
        "width": 1400,
        "height": 903
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/s6E1tMLfLK6Gnys7FURqD3",
        "aspectRatio": 6.956521739130435
      },
      {
        "type": "image",
        "src": "assets/cases/voks/02.webp",
        "alt": "Вокс — разворот 3",
        "width": 2800,
        "height": 1596
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/f733ufg7gm7XuBwiYfkkR8",
        "aspectRatio": 1.555451858764971
      },
      {
        "type": "image",
        "src": "assets/cases/voks/04.webp",
        "alt": "Вокс — разворот 5",
        "width": 1400,
        "height": 713
      },
      {
        "type": "image",
        "src": "assets/cases/voks/05.webp",
        "alt": "Вокс — разворот 6",
        "width": 1400,
        "height": 794
      },
      {
        "type": "image",
        "src": "assets/cases/voks/06.webp",
        "alt": "Вокс — разворот 7",
        "width": 1400,
        "height": 850
      },
      {
        "type": "image",
        "src": "assets/cases/voks/07.webp",
        "alt": "Вокс — разворот 8",
        "width": 1400,
        "height": 1000
      },
      {
        "type": "image",
        "src": "assets/cases/voks/08.webp",
        "alt": "Вокс — разворот 9",
        "width": 1400,
        "height": 850
      },
      {
        "type": "embed",
        "src": "https://kinescope.io/embed/dp7uRG82cLMvP4Qo8xahsV",
        "aspectRatio": 9.337068160597571
      },
      {
        "type": "image",
        "src": "assets/cases/voks/10.webp",
        "alt": "Вокс — разворот 11",
        "width": 1400,
        "height": 750
      }
    ]
  },
  {
    "id": "marketplaces",
    "title": "WB · Ozon",
    "subtitle": "Карточки товаров",
    "tags": "инфографика · маркетплейсы",
    "year": "2025",
    "cover": "assets/work/wb-cover.webp",
    "description": "Подборка инфографики и карточек товаров для Wildberries и Ozon. Визуальные акценты, понятная иерархия и внимание к деталям.",
    "url": "https://www.behance.net/gallery/227799001/infografikadizajn-kartochek-wildberries-ozon",
    "media": [
      {
        "type": "image",
        "src": "assets/cases/marketplaces/00.webp",
        "alt": "WB · Ozon — разворот 1",
        "width": 2800,
        "height": 1817
      },
      {
        "type": "image",
        "src": "assets/cases/marketplaces/01.webp",
        "alt": "WB · Ozon — разворот 2",
        "width": 1400,
        "height": 670
      },
      {
        "type": "image",
        "src": "assets/cases/marketplaces/02.webp",
        "alt": "WB · Ozon — разворот 3",
        "width": 1400,
        "height": 881
      },
      {
        "type": "image",
        "src": "assets/cases/marketplaces/03.webp",
        "alt": "WB · Ozon — разворот 4",
        "width": 1400,
        "height": 1015
      },
      {
        "type": "image",
        "src": "assets/cases/marketplaces/04.webp",
        "alt": "WB · Ozon — разворот 5",
        "width": 1400,
        "height": 806
      },
      {
        "type": "image",
        "src": "assets/cases/marketplaces/05.webp",
        "alt": "WB · Ozon — разворот 6",
        "width": 1400,
        "height": 1746
      },
      {
        "type": "image",
        "src": "assets/cases/marketplaces/06.webp",
        "alt": "WB · Ozon — разворот 7",
        "width": 1400,
        "height": 937
      }
    ]
  }
];
