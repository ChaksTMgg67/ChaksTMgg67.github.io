const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const easeOut = t => 1 - Math.pow(1 - t, 3);
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

/* появление при скролле */
const io = new IntersectionObserver(es => es.forEach(e => {
  if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
}), { threshold: 0.15, rootMargin: '0px 0px -8% 0px' });
$$('.rv, .mask, .bento figure').forEach(el => io.observe(el));
// первый экран показываем сразу, не дожидаясь скролла
requestAnimationFrame(() => $$('.hero .rv, .hero .mask').forEach(el => el.classList.add('in')));

/* манифест: слова загораются */
const sp = $('[data-words]');
(function split(node) {
  [...node.childNodes].forEach(n => {
    if (n.nodeType === 3) {
      const frag = document.createDocumentFragment();
      n.textContent.split(/(\s+)/).forEach(w => {
        if (!w.trim()) { frag.append(w); return; }
        const s = document.createElement('span'); s.className = 'w'; s.textContent = w;
        if (node.hasAttribute && node.hasAttribute('data-acc')) s.classList.add('acc');
        frag.append(s);
      });
      n.replaceWith(frag);
    } else split(n);
  });
})(sp);
const words = $$('.w', sp);

/* таймлайн */
const STAGES = [
  { y: '2022', t: 'Первые макеты', d: 'В 14 лет открыл Photoshop и не закрыл. Обложки, аватарки, первые заказы за копейки.', w: 340 },
  { y: '2023', t: 'Маркетплейсы', d: 'Карточки для Wildberries и Ozon. Научился продавать картинкой и держать дедлайны.', w: 420, img: 'assets/work/wb-cover.webp' },
  { y: '2024', t: 'Фирменный стиль', d: 'Начинаю учиться фирменному стилю и беру первые проекты по айдентике.', w: 380 },
  { y: '2025', t: 'Брендинг', d: 'От отдельных картинок к системам: логотипы, айдентика, упаковка.', w: 360, img: 'assets/work/voks-colors.webp' },
  { y: '2026', t: 'Swallow × Вокс', d: 'Две полноценные айдентики: кофейня и школа вокала. Брендинг, упаковка, моушн.', w: 460, img: 'assets/work/swallow-cup.webp' },
  { y: '2026', t: 'Дизайн Долганова', d: 'Запустил блог про дизайн: рилсы, разборы, моушн-графика.', w: 400, img: 'assets/avatar.webp' },
  { y: 'Сейчас', t: 'B&D', d: 'Учусь в B&D — Институте бизнеса и дизайна на направлении «Цифровые коммуникации».', w: 380, now: true },
];
const track = $('#track'), view = $('#view');
const LBL = 44, GAP = 8, LEAD = 0;
let trackW = 0;
function buildTrack() {
  const H = view.clientHeight, rh = 30, laneH = (H - rh - 4 * GAP) / 3;
  track.innerHTML = '';
  const ruler = document.createElement('div'); ruler.className = 'ruler'; track.append(ruler);
  const lanes = ['V2', 'V1', 'A1'].map((n, i) => {
    const l = document.createElement('div'); l.className = 'lane';
    l.style.top = rh + GAP + i * (laneH + GAP) + 'px'; l.style.height = laneH + 'px';
    track.append(l); return l;
  });
  let x = 0;
  STAGES.forEach((s, i) => {
    s.x = x;
    const c = document.createElement('div'); c.className = 'clip' + (s.now ? ' now' : '');
    c.style.left = x + 'px'; c.style.width = s.w - 6 + 'px';
    c.innerHTML = `<small>[ ${String(i + 1).padStart(2, '0')} ] ${s.y}</small><b>${s.t}</b>`;
    lanes[1].append(c); s.el = c;
    if (s.img) {
      const v = document.createElement('div'); v.className = 'vclip';
      v.style.left = x + 'px'; v.style.width = Math.min(160, s.w - 6) + 'px';
      v.innerHTML = `<img src="${s.img}" alt="" loading="lazy" decoding="async">`; lanes[0].append(v);
    }
    const r = document.createElement('span'); r.textContent = s.y; r.style.left = x + 'px'; ruler.append(r);
    x += s.w;
  });
  trackW = x;
  // звуковая дорожка на всю длину
  const wv = document.createElement('div'); wv.className = 'wave';
  wv.style.left = '0px'; wv.style.width = trackW - 6 + 'px';
  const n = Math.floor(trackW / 8);
  for (let i = 0; i < n; i++) {
    const b = document.createElement('i');
    b.style.height = (18 + 70 * Math.abs(Math.sin(i * 0.37) * Math.cos(i * 0.11 + 1))) + '%';
    wv.append(b);
  }
  lanes[2].append(wv);
  ruler.style.width = trackW + 'px';
}
buildTrack();
let rT; addEventListener('resize', () => { clearTimeout(rT); rT = setTimeout(() => { buildTrack(); active = -1; scheduleFrame(); }, 150); });

let active = -1;
const detail = $('#detail'), dYear = $('#dYear'), dTitle = $('#dTitle'), dText = $('#dText');
function setActive(i) {
  if (i === active) return;
  STAGES.forEach((s, k) => s.el.classList.toggle('on', k === i));
  const s = STAGES[i];
  if (active === -1) { dYear.textContent = s.y; dTitle.textContent = s.t; dText.textContent = s.d; active = i; return; }
  active = i;
  detail.classList.add('out');
  clearTimeout(setActive.t);
  setActive.t = setTimeout(() => {
    dYear.textContent = s.y; dTitle.textContent = s.t; dText.textContent = s.d;
    detail.classList.remove('out');
  }, 260);
}

/* кадр */
const prog = $('.progress'), glow = $('.bg i'), tc = $('#tc');
const pathSec = $('#path'), stSec = $('#statement');
function secProgress(el) {
  const r = el.getBoundingClientRect();
  return clamp(-r.top / Math.max(1, r.height - innerHeight));
}
let framePending = false;
let lastLit = -1, lastTc = '';
function frame() {
  framePending = false;
  if (document.hidden || document.querySelector('dialog[open]')) return;
  // Сначала все чтения, потом записи — чтобы браузер не пересчитывал раскладку посреди кадра.
  const max = document.documentElement.scrollHeight - innerHeight;
  const y = scrollY, vh = innerHeight;
  const sr = stSec.getBoundingClientRect(), pr = pathSec.getBoundingClientRect();
  const stNear = sr.bottom > -vh && sr.top < vh * 2, pathNear = pr.bottom > 0 && pr.top < vh;
  const vw = pathNear ? view.clientWidth : 0;

  prog.style.transform = `scaleX(${max ? y / max : 0})`;

  // манифест — только пока секция рядом с экраном
  if (stNear) {
    const sp1 = clamp(-sr.top / Math.max(1, sr.height - vh));
    const lit = reduce ? words.length : Math.floor(sp1 * 1.25 * words.length);
    if (lit !== lastLit) { words.forEach((w, i) => w.classList.toggle('on', i < lit)); lastLit = lit; }
  }

  // таймлайн — только когда он на экране
  if (pathNear) {
    const pp = clamp(-pr.top / Math.max(1, pr.height - vh));
    const pos = pp * (trackW - 1);
    track.style.transform = `translate3d(${vw / 2 - pos}px,0,0)`;
    let idx = STAGES.findIndex(s => pos >= s.x && pos < s.x + s.w);
    if (idx < 0) idx = STAGES.length - 1;
    setActive(idx);
    const f = Math.floor(pp * 30 * 60 * 2.5);
    const pad = n => String(n).padStart(2, '0');
    const t = `00:${pad(Math.floor(f / 1800) % 60)}:${pad(Math.floor(f / 30) % 60)}:${pad(f % 30)}`;
    if (t !== lastTc) { tc.textContent = t; lastTc = t; }
  }
}
function scheduleFrame() {
  if (!framePending) { framePending = true; requestAnimationFrame(frame); }
}
addEventListener('scroll', scheduleFrame, { passive: true });
addEventListener('resize', scheduleFrame, { passive: true });
addEventListener('load', scheduleFrame);
document.addEventListener('visibilitychange', scheduleFrame);
document.fonts.ready.then(scheduleFrame);
scheduleFrame();

/* A small gradient highlight follows a mouse only while it moves. */
const cur = $('.cursor');
document.addEventListener('visibilitychange',()=>{document.body.classList.toggle('effects-paused',document.hidden);});
if (matchMedia('(hover:hover) and (pointer:fine)').matches && !reduce) {
  let cx=0, cy=0, tx=0, ty=0, cursorFrame=0, seen=false;
  const moveCursor = () => {
    cx+=(tx-cx)*.3; cy+=(ty-cy)*.3;
    cur.style.transform=`translate3d(${cx}px,${cy}px,0)`;
    if(Math.abs(tx-cx)+Math.abs(ty-cy)>.15) cursorFrame=requestAnimationFrame(moveCursor);
    else cursorFrame=0;
  };
  document.addEventListener('pointermove',e=>{
    if(e.pointerType!=='mouse')return;
    tx=e.clientX;ty=e.clientY;
    if(!seen){cx=tx;cy=ty;seen=true;}
    cur.classList.add('visible');
    
    if(!cursorFrame)cursorFrame=requestAnimationFrame(moveCursor);
  },{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(cursorFrame);cursorFrame=0;cur.classList.remove('visible');}});
  document.documentElement.addEventListener('pointerleave',()=>cur.classList.remove('visible'));
  window.addEventListener('blur',()=>cur.classList.remove('visible'));
} else cur.remove();

// Keep the section switch useful while browsing the portfolio.
const sectionLinks=[...document.querySelectorAll('.work-switch a')];
const sectionWatch=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){sectionLinks.forEach(a=>{if(a.hash==='#'+e.target.id)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});}});},{rootMargin:'-15% 0px -60% 0px'});
['work','posters','cards','vk'].forEach(id=>sectionWatch.observe(document.getElementById(id)));

/* Фото на первом экране слегка поворачивается за мышью, плашки вокруг сдвигаются с разной глубиной. */
(() => {
  const hero = document.querySelector('.hero'), wrap = hero?.querySelector('.photo-wrap'), card = wrap?.querySelector('.photo');
  if (!card) return;
  // плашки не анимируются, когда первый экран вне видимости
  new IntersectionObserver(([e]) => hero.classList.toggle('hero-off', !e.isIntersecting)).observe(hero);
  if (reduce || !matchMedia('(hover:hover) and (pointer:fine)').matches) return;
  hero.addEventListener('pointermove', e => {
    const r = wrap.getBoundingClientRect();
    const x = (e.clientX - (r.left + r.width / 2)) / innerWidth, y = (e.clientY - (r.top + r.height / 2)) / innerHeight;
    card.style.transform = `rotate(3deg) rotateY(${x * 14}deg) rotateX(${-y * 10}deg)`;
    wrap.style.setProperty('--mx', (x * 2).toFixed(3)); wrap.style.setProperty('--my', (y * 2).toFixed(3));
  });
  hero.addEventListener('pointerleave', () => { card.style.transform = ''; wrap.style.setProperty('--mx', 0); wrap.style.setProperty('--my', 0); });
})();

/* Навигация: подсвечиваем текущий раздел, прячем меню при прокрутке вниз, мобильное меню. */
(() => {
  const nav = document.querySelector('.nav'), ind = nav.querySelector('.nav__ind'), links = [...nav.querySelectorAll('a.l')];
  const moveInd = a => {
    links.forEach(l => l === a ? l.setAttribute('aria-current', 'true') : l.removeAttribute('aria-current'));
    if (!a) { ind.style.opacity = 0; return; }
    ind.style.opacity = 1; ind.style.width = a.offsetWidth + 'px'; ind.style.transform = `translateX(${a.offsetLeft}px)`;
  };
  const owner = id => links.find(l => l.dataset.sec.split(' ').includes(id));
  const ids = ['top', 'statement', 'work', 'posters', 'cards', 'vk', 'about', 'path', 'process', 'contact'];
  const seen = new Map();
  const io = new IntersectionObserver(es => {
    es.forEach(e => seen.set(e.target.id, e.isIntersecting));
    const cur = ids.find(id => seen.get(id));
    moveInd(cur ? owner(cur) : null);
  }, { rootMargin: '-45% 0px -50% 0px' });
  ids.forEach(id => { const el = document.getElementById(id); if (el) io.observe(el); });

  let lastY = scrollY, ticking = false;
  addEventListener('scroll', () => {
    if (ticking) return; ticking = true;
    requestAnimationFrame(() => {
      const y = scrollY, menuOpen = burger.getAttribute('aria-expanded') === 'true';
      nav.classList.toggle('nav--hide', !menuOpen && y > innerHeight * .8 && y > lastY + 4);
      if (y < lastY - 4 || y < innerHeight * .8) nav.classList.remove('nav--hide');
      lastY = y; ticking = false;
    });
  }, { passive: true });

  const burger = nav.querySelector('.nav__burger'), menu = document.getElementById('menu');
  [...menu.querySelectorAll('a')].forEach((a, k) => a.style.setProperty('--k', k));
  const setMenu = open => {
    burger.setAttribute('aria-expanded', String(open)); burger.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) { menu.hidden = false; requestAnimationFrame(() => menu.classList.add('open')); }
    else { menu.classList.remove('open'); setTimeout(() => { if (!menu.classList.contains('open')) menu.hidden = true; }, 400); }
  };
  burger.addEventListener('click', () => setMenu(burger.getAttribute('aria-expanded') !== 'true'));
  menu.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });
  addEventListener('keydown', e => { if (e.key === 'Escape' && burger.getAttribute('aria-expanded') === 'true') setMenu(false); });
})();

/* Инструменты: при наведении или нажатии показываем, для чего программа. */
(() => {
  const list = document.querySelector('.tools-list'), out = document.querySelector('.tools-what');
  if (!list) return;
  const idle = out.textContent, btns = [...list.querySelectorAll('button')];
  const show = b => { btns.forEach(x => x.setAttribute('aria-pressed', String(x === b))); out.innerHTML = b ? `<b>${b.textContent}</b> — ${b.dataset.what}` : idle; };
  btns.forEach(b => {
    b.addEventListener('mouseenter', () => show(b));
    b.addEventListener('focus', () => show(b));
    b.addEventListener('click', () => show(b));
  });
  list.addEventListener('mouseleave', () => show(null));
})();

/* Переходы по ссылкам внутри страницы: едем к разделу и, если по пути догрузились картинки
   и раздел сдвинулся, доводим до точного места. Новое нажатие отменяет доводку прошлого. */
(() => {
  const offset = () => (innerWidth < 861 ? 76 : 92);
  const topOf = el => el.getBoundingClientRect().top + scrollY - offset();
  let job = 0, pendingFix = null;
  const cancelFix = () => { if (pendingFix) { removeEventListener('scrollend', pendingFix); pendingFix = null; } };
  // если человек сам крутит колесо или палец — не мешаем ему
  ['wheel', 'touchstart', 'keydown'].forEach(t => addEventListener(t, e => { if (t !== 'keydown' || ['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '].includes(e.key)) { job++; cancelFix(); } }, { passive: true }));
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href^="#"]');
    if (!a || a.closest('dialog') || a.getAttribute('href').startsWith('#project/')) return;
    const id = a.getAttribute('href').slice(1), el = id && document.getElementById(id);
    if (!el) return;
    e.preventDefault();
    const my = ++job; cancelFix();
    const go = smooth => scrollTo({ top: Math.max(0, topOf(el)), behavior: smooth && !reduce ? 'smooth' : 'auto' });
    go(true);
    history.replaceState(null, '', '#' + id);
    let tries = 0;
    const fix = () => {
      pendingFix = null;
      if (my !== job || Math.abs(topOf(el) - scrollY) <= 8 || tries++ >= 4) return;
      go(tries < 3); arm();
    };
    const arm = () => { if ('onscrollend' in window) { pendingFix = fix; addEventListener('scrollend', fix, { once: true }); } else setTimeout(fix, 900); };
    arm();
  });
})();
