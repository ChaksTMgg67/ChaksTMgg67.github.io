// Ролик построения знака Swallow: плеер грузится рядом с экраном и выгружается вдали, как в кейсах.
(() => {
 const f=document.querySelector('#build iframe[data-src]');if(!f)return;
 new IntersectionObserver(es=>es.forEach(e=>{
  if(e.isIntersecting){if(!f.hasAttribute('src'))f.src=f.dataset.src;}
  else if(f.hasAttribute('src'))f.removeAttribute('src');
 }),{rootMargin:'600px'}).observe(f);
})();
